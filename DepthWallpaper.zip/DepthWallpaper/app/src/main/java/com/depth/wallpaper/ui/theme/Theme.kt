package com.depth.wallpaper.ui.theme

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// ---- Design tokens ----
val Amoled = Color(0xFF000000)
val Navy = Color(0xFF0A1128)
val NavySurface = Color(0xFF111B3A)
val ElectricBlue = Color(0xFF2F6BFF)
val NeonPurple = Color(0xFFA85BFF)
val NeonCyan = Color(0xFF35E0FF)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFA9B4D0)
val GoldPro = Color(0xFFFFC53D)
val HeartRed = Color(0xFFFF4D6D)
val BrandGradient = Brush.horizontalGradient(listOf(ElectricBlue, NeonPurple))
val BlueGradient = Brush.horizontalGradient(listOf(Color(0xFF2F6BFF), Color(0xFF5B8CFF)))

@Composable
fun DepthTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = ElectricBlue,
            secondary = NeonPurple,
            tertiary = NeonCyan,
            background = Amoled,
            surface = NavySurface,
            onPrimary = Color.White,
            onBackground = TextPrimary,
            onSurface = TextPrimary
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Amoled, contentColor = TextPrimary, content = content)
    }
}
