package com.depth.wallpaper.ui

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.depth.wallpaper.data.DownloadedFile
import com.depth.wallpaper.data.Downloader
import com.depth.wallpaper.data.PrefsStore
import com.depth.wallpaper.data.Resolution
import com.depth.wallpaper.data.Wallpaper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = PrefsStore(app)
    private val downloader = Downloader(app)

    val favorites: StateFlow<Set<String>> =
        prefs.favorites.stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())
    val quality: StateFlow<Resolution> =
        prefs.quality.stateIn(viewModelScope, SharingStarted.Eagerly, Resolution.QHD)

    /** key = "<wallpaperId>__<RES>", value = 0..1 */
    private val _progress = MutableStateFlow<Map<String, Float>>(emptyMap())
    val progress: StateFlow<Map<String, Float>> = _progress.asStateFlow()

    private val _downloads = MutableStateFlow<List<DownloadedFile>>(emptyList())
    val downloads: StateFlow<List<DownloadedFile>> = _downloads.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    init {
        refreshDownloads()
    }

    fun say(msg: String) {
        _messages.tryEmit(msg)
    }

    fun toggleFavorite(id: String) {
        viewModelScope.launch { prefs.toggleFavorite(id) }
    }

    fun setQuality(r: Resolution) {
        viewModelScope.launch { prefs.setQuality(r) }
    }

    fun refreshDownloads() {
        viewModelScope.launch(Dispatchers.IO) { _downloads.value = downloader.list() }
    }

    /** Returns the file immediately if already downloaded (no duplicate downloads). */
    suspend fun fetch(w: Wallpaper, r: Resolution): Result<File> {
        val existing = downloader.fileFor(w, r)
        if (existing.exists() && existing.length() > 0) return Result.success(existing)
        val key = "${w.id}__${r.name}"
        if (key in _progress.value) return Result.failure(IllegalStateException("Already downloading"))
        _progress.update { it + (key to 0f) }
        return try {
            val f = downloader.download(w, r) { p -> _progress.update { m -> m + (key to p) } }
            Result.success(f)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            _progress.update { it - key }
            refreshDownloads()
        }
    }

    fun download(w: Wallpaper, r: Resolution) {
        viewModelScope.launch {
            val already = downloader.fileFor(w, r).exists()
            fetch(w, r)
                .onSuccess { say(if (already) "Already downloaded (${r.label})" else "Saved ${r.label} wallpaper") }
                .onFailure { say("Download failed. Check your connection and tap Download to retry.") }
        }
    }

    fun delete(d: DownloadedFile) {
        viewModelScope.launch(Dispatchers.IO) {
            d.file.delete()
            _downloads.value = downloader.list()
        }
    }

    suspend fun saveEdited(bmp: Bitmap): File = withContext(Dispatchers.IO) {
        val f = File(downloader.dir, "custom_${System.currentTimeMillis()}__EDIT.jpg")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        _downloads.value = downloader.list()
        f
    }
}
