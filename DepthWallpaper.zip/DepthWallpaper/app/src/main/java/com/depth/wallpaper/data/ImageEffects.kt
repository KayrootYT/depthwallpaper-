package com.depth.wallpaper.data

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Real, on-device image processing (no AI, no network). */
object ImageEffects {

    fun titleFor(effect: String) = when (effect) {
        "blur" -> "Blur Effect"
        "filters" -> "Color Filters"
        "3d" -> "3D Effect"
        else -> "Artistic Styles"
    }

    fun optionsFor(effect: String): List<String> = when (effect) {
        "blur" -> emptyList()
        "filters" -> listOf("Mono", "Sepia", "Vivid", "Cool", "Warm", "Invert")
        "3d" -> listOf("Chromatic", "Anaglyph")
        else -> listOf("Pixel", "Posterize", "Duotone")
    }

    fun apply(effect: String, src: Bitmap, option: Int, strength: Float): Bitmap = when (effect) {
        "blur" -> blur(src, strength)
        "filters" -> colorFilter(src, option, strength)
        "3d" -> effect3d(src, option, strength)
        else -> when (option) {
            0 -> pixelate(src, strength)
            1 -> posterize(src, strength)
            else -> duotone(src, strength)
        }
    }

    private fun blur(src: Bitmap, strength: Float): Bitmap {
        if (strength <= 0.01f) return src
        val shortSide = min(src.width, src.height)
        val target = max(8, (shortSide / (1f + strength * 40f)).toInt())
        val ratio = target.toFloat() / shortSide
        val tw = max(2, (src.width * ratio).toInt())
        val th = max(2, (src.height * ratio).toInt())
        var cur = src
        while (cur.width / 2 > tw && cur.height / 2 > th) {
            cur = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
        }
        cur = Bitmap.createScaledBitmap(cur, tw, th, true)
        while (cur.width * 2 < src.width && cur.height * 2 < src.height) {
            cur = Bitmap.createScaledBitmap(cur, cur.width * 2, cur.height * 2, true)
        }
        return Bitmap.createScaledBitmap(cur, src.width, src.height, true)
    }

    private fun colorFilter(src: Bitmap, option: Int, strength: Float): Bitmap {
        val cm = when (option) {
            0 -> ColorMatrix().apply { setSaturation(0f) }
            1 -> ColorMatrix(floatArrayOf(
                0.393f, 0.769f, 0.189f, 0f, 0f,
                0.349f, 0.686f, 0.168f, 0f, 0f,
                0.272f, 0.534f, 0.131f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f))
            2 -> ColorMatrix().apply { setSaturation(1.9f) }
            3 -> ColorMatrix(floatArrayOf(
                0.9f, 0f, 0f, 0f, 0f,
                0f, 1f, 0f, 0f, 0f,
                0f, 0f, 1.25f, 0f, 12f,
                0f, 0f, 0f, 1f, 0f))
            4 -> ColorMatrix(floatArrayOf(
                1.2f, 0f, 0f, 0f, 12f,
                0f, 1.05f, 0f, 0f, 0f,
                0f, 0f, 0.85f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f))
            else -> ColorMatrix(floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f))
        }
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawBitmap(src, 0f, 0f, null)
        val paint = Paint().apply {
            colorFilter = ColorMatrixColorFilter(cm)
            alpha = (strength * 255).toInt().coerceIn(0, 255)
        }
        canvas.drawBitmap(src, 0f, 0f, paint)
        return out
    }

    private fun effect3d(src: Bitmap, option: Int, strength: Float): Bitmap {
        val w = src.width
        val h = src.height
        val shift = max(1, (strength * 0.03f * w).toInt())
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val out = IntArray(w * h)
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                val c = px[row + x]
                val left = px[row + max(0, x - shift)]
                val right = px[row + min(w - 1, x + shift)]
                val rSrc = left
                val gSrc = if (option == 0) c else right
                val bSrc = right
                out[row + x] = (0xFF shl 24) or
                    (((rSrc shr 16) and 0xFF) shl 16) or
                    (((gSrc shr 8) and 0xFF) shl 8) or
                    (bSrc and 0xFF)
            }
        }
        val res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        res.setPixels(out, 0, w, 0, 0, w, h)
        return res
    }

    private fun pixelate(src: Bitmap, strength: Float): Bitmap {
        val block = (4 + strength * 44f).toInt()
        val w = max(1, src.width / block)
        val h = max(1, src.height / block)
        val small = Bitmap.createScaledBitmap(src, w, h, true)
        return Bitmap.createScaledBitmap(small, src.width, src.height, false)
    }

    private fun posterize(src: Bitmap, strength: Float): Bitmap {
        val levels = (12 - strength * 9f).toInt().coerceIn(2, 12)
        val step = 255f / (levels - 1)
        val lut = IntArray(256) { v -> ((v / step).roundToInt() * step).roundToInt().coerceIn(0, 255) }
        return mapPixels(src) { c ->
            (0xFF shl 24) or
                (lut[(c shr 16) and 0xFF] shl 16) or
                (lut[(c shr 8) and 0xFF] shl 8) or
                lut[c and 0xFF]
        }
    }

    private fun duotone(src: Bitmap, strength: Float): Bitmap {
        val dark = 0x0A0F2E
        val light = lerpRgb(0x35E0FF, 0xA85BFF, strength)
        val lut = IntArray(256) { l -> lerpRgb(dark, light, l / 255f) or (0xFF shl 24) }
        return mapPixels(src) { c ->
            val lum = (((c shr 16) and 0xFF) * 299 + ((c shr 8) and 0xFF) * 587 + (c and 0xFF) * 114) / 1000
            lut[lum.coerceIn(0, 255)]
        }
    }

    private fun lerpRgb(a: Int, b: Int, t: Float): Int {
        fun ch(shift: Int): Int {
            val x = (a shr shift) and 0xFF
            val y = (b shr shift) and 0xFF
            return (x + (y - x) * t).roundToInt().coerceIn(0, 255)
        }
        return (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }

    private inline fun mapPixels(src: Bitmap, f: (Int) -> Int): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) px[i] = f(px[i])
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }
}
