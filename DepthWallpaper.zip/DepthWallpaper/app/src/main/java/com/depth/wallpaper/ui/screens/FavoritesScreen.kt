package com.depth.wallpaper.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.depth.wallpaper.data.WallpaperRepository
import com.depth.wallpaper.ui.AppViewModel
import com.depth.wallpaper.ui.components.EmptyState
import com.depth.wallpaper.ui.components.TopBar

@Composable
fun FavoritesScreen(vm: AppViewModel, nav: NavHostController) {
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val list = remember(favs) { WallpaperRepository.all.filter { it.id in favs } }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        TopBar("Favorites")
        if (list.isEmpty()) {
            EmptyState(
                icon = Icons.Outlined.FavoriteBorder,
                title = "No favourites yet",
                subtitle = "Tap the heart on any wallpaper to save it here.",
                actionLabel = "Explore Wallpapers",
                onAction = { nav.navigate("explore") }
            )
        } else {
            WallpaperGrid(
                list = list,
                favs = favs,
                onFav = { vm.toggleFavorite(it.id) },
                onOpen = { nav.navigate("preview/${it.id}") }
            )
        }
    }
}
