package com.depth.wallpaper.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "depth_prefs")

/** Favourites + user preferences, persisted with DataStore. */
class PrefsStore(private val ctx: Context) {
    private val favKey = stringSetPreferencesKey("favorites")
    private val qualityKey = stringPreferencesKey("quality")

    val favorites: Flow<Set<String>> = ctx.dataStore.data.map { it[favKey] ?: emptySet() }

    val quality: Flow<Resolution> = ctx.dataStore.data.map { p ->
        p[qualityKey]?.let { name -> runCatching { Resolution.valueOf(name) }.getOrNull() } ?: Resolution.QHD
    }

    suspend fun toggleFavorite(id: String) {
        ctx.dataStore.edit { p ->
            val cur = p[favKey] ?: emptySet()
            p[favKey] = if (id in cur) cur - id else cur + id
        }
    }

    suspend fun setQuality(r: Resolution) {
        ctx.dataStore.edit { it[qualityKey] = r.name }
    }
}

data class DownloadedFile(
    val file: File,
    val title: String,
    val resolution: String,
    val wallpaperId: String?,
    val sizeBytes: Long,
    val modified: Long
)

/** Saves wallpapers into app-private storage (no storage permission needed, works offline). */
class Downloader(private val ctx: Context) {
    val dir: File get() = File(ctx.filesDir, "wallpapers").apply { mkdirs() }

    fun fileFor(w: Wallpaper, r: Resolution) = File(dir, "${w.id}__${r.name}.jpg")

    suspend fun download(w: Wallpaper, r: Resolution, onProgress: (Float) -> Unit): File =
        withContext(Dispatchers.IO) {
            val target = fileFor(w, r)
            if (target.exists() && target.length() > 0) return@withContext target
            val tmp = File(dir, target.name + ".part")
            val conn = URL(w.url(r)).openConnection() as HttpURLConnection
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            conn.instanceFollowRedirects = true
            try {
                if (conn.responseCode !in 200..299) throw IOException("HTTP ${conn.responseCode}")
                val total = conn.contentLengthLong
                conn.inputStream.use { input ->
                    tmp.outputStream().use { out ->
                        val buf = ByteArray(16 * 1024)
                        var done = 0L
                        var last = 0f
                        while (true) {
                            val n = input.read(buf)
                            if (n == -1) break
                            ensureActive()
                            out.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val p = done.toFloat() / total
                                if (p - last >= 0.02f) {
                                    last = p
                                    onProgress(p)
                                }
                            }
                        }
                    }
                }
                if (!tmp.renameTo(target)) throw IOException("Could not save file")
                onProgress(1f)
                target
            } catch (e: Exception) {
                tmp.delete()
                throw e
            } finally {
                conn.disconnect()
            }
        }

    fun list(): List<DownloadedFile> =
        dir.listFiles()?.filter { it.extension == "jpg" }.orEmpty().map { f ->
            val base = f.nameWithoutExtension
            val id = base.substringBefore("__")
            val resName = base.substringAfter("__", "")
            val wp = WallpaperRepository.byId(id)
            DownloadedFile(
                file = f,
                title = wp?.title ?: "Custom wallpaper",
                resolution = Resolution.values().firstOrNull { it.name == resName }?.label ?: "Custom",
                wallpaperId = wp?.id,
                sizeBytes = f.length(),
                modified = f.lastModified()
            )
        }.sortedByDescending { it.modified }
}
