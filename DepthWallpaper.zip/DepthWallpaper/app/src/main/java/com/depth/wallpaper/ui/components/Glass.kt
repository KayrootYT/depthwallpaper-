package com.depth.wallpaper.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.BrokenImage
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.depth.wallpaper.data.Wallpaper
import com.depth.wallpaper.data.WallpaperTarget
import com.depth.wallpaper.ui.theme.BlueGradient
import com.depth.wallpaper.ui.theme.BrandGradient
import com.depth.wallpaper.ui.theme.ElectricBlue
import com.depth.wallpaper.ui.theme.HeartRed
import com.depth.wallpaper.ui.theme.NavySurface
import com.depth.wallpaper.ui.theme.NeonCyan
import com.depth.wallpaper.ui.theme.TextPrimary
import com.depth.wallpaper.ui.theme.TextSecondary

/** Translucent "liquid glass" surface: soft gradient fill + light border + optional glow. */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    glow: Color? = null,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    var m = modifier
    if (glow != null) m = m.shadow(18.dp, shape, ambientColor = glow, spotColor = glow)
    m = m.clip(shape)
        .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.14f), Color.White.copy(alpha = 0.04f))))
        .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.35f), Color.White.copy(alpha = 0.05f))), shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Box(modifier = m, content = content)
}

@Composable
fun GlassIconButton(
    icon: ImageVector,
    desc: String,
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    size: Dp = 44.dp,
    onClick: () -> Unit
) {
    GlassSurface(modifier.size(size), CircleShape, onClick = onClick) {
        Icon(icon, desc, tint = tint, modifier = Modifier.align(Alignment.Center).size(size * 0.5f))
    }
}

@Composable
fun GradientButton(
    text: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    progress: Float? = null,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    Box(
        modifier
            .height(54.dp)
            .shadow(14.dp, shape, ambientColor = ElectricBlue, spotColor = ElectricBlue)
            .clip(shape)
            .background(BlueGradient)
            .border(1.dp, Color.White.copy(alpha = 0.3f), shape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (progress != null) {
            Box(
                Modifier
                    .align(Alignment.CenterStart)
                    .fillMaxHeight()
                    .fillMaxWidth(progress.coerceIn(0f, 1f))
                    .background(Color.White.copy(alpha = 0.22f))
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (icon != null) Icon(icon, null, tint = Color.White)
            Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        }
    }
}

@Composable
fun GlassChip(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    val bg = if (selected) Modifier.background(BrandGradient) else Modifier.background(Color.White.copy(alpha = 0.08f))
    Text(
        text,
        color = if (selected) Color.White else TextSecondary,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        modifier = modifier
            .clip(shape)
            .then(bg)
            .border(1.dp, Color.White.copy(alpha = if (selected) 0f else 0.15f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

@Composable
fun ShimmerBox(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "shimmer")
    val x by t.animateFloat(
        initialValue = -300f,
        targetValue = 1200f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing)),
        label = "shimmerX"
    )
    Box(
        modifier.background(
            Brush.linearGradient(
                listOf(Color(0xFF111A33), Color(0xFF24335E), Color(0xFF111A33)),
                start = Offset(x, 0f),
                end = Offset(x + 300f, 300f)
            )
        )
    )
}

/** Coil image with shimmer skeleton while loading and a broken-image state on error. */
@Composable
fun AppImage(
    model: Any?,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    placeholderUrl: String? = null
) {
    val ctx = LocalContext.current
    SubcomposeAsyncImage(
        model = ImageRequest.Builder(ctx).data(model).crossfade(true).build(),
        contentDescription = null,
        modifier = modifier,
        contentScale = contentScale,
        loading = {
            if (placeholderUrl != null) AppImage(placeholderUrl, Modifier.fillMaxSize(), contentScale)
            else ShimmerBox(Modifier.fillMaxSize())
        },
        error = {
            Box(Modifier.fillMaxSize().background(NavySurface), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.BrokenImage, "Image failed to load", tint = TextSecondary)
            }
        }
    )
}

@Composable
fun WallpaperCard(
    w: Wallpaper,
    favorite: Boolean,
    onToggleFav: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    badge: String? = null
) {
    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier
            .aspectRatio(9f / 16f)
            .clip(shape)
            .border(1.dp, Color.White.copy(alpha = 0.12f), shape)
            .clickable(onClick = onClick)
    ) {
        AppImage(w.thumb(), Modifier.fillMaxSize())
        Box(
            Modifier
                .fillMaxWidth()
                .height(80.dp)
                .align(Alignment.BottomCenter)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.6f))))
        )
        if (badge != null) {
            Text(
                badge,
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black.copy(alpha = 0.5f))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            )
        }
        GlassIconButton(
            icon = if (favorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
            desc = if (favorite) "Remove from favourites" else "Add to favourites",
            modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp),
            tint = if (favorite) HeartRed else Color.White,
            size = 34.dp,
            onClick = onToggleFav
        )
    }
}

@Composable
fun SectionHeader(
    title: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    Row(
        modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (actionLabel != null && onAction != null) {
            Text(
                "$actionLabel ›",
                color = NeonCyan,
                fontSize = 13.sp,
                modifier = Modifier.clickable(onClick = onAction)
            )
        }
    }
}

@Composable
fun TopBar(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            GlassIconButton(Icons.AutoMirrored.Outlined.ArrowBack, "Back", onClick = onBack)
            Spacer(Modifier.width(12.dp))
        }
        Text(title, color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        actions()
    }
}

@Composable
fun EmptyState(
    icon: ImageVector,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    Column(
        modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        GlassSurface(Modifier.size(88.dp), CircleShape, glow = ElectricBlue.copy(alpha = 0.5f)) {
            Icon(icon, null, tint = NeonCyan, modifier = Modifier.align(Alignment.Center).size(40.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text(title, color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(subtitle, color = TextSecondary, fontSize = 14.sp, textAlign = TextAlign.Center)
        if (actionLabel != null && onAction != null) {
            Spacer(Modifier.height(20.dp))
            GradientButton(text = actionLabel, modifier = Modifier.fillMaxWidth(0.75f), onClick = onAction)
        }
    }
}

@Composable
fun SetWallpaperDialog(onDismiss: () -> Unit, onPick: (Int) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NavySurface,
        title = { Text("Set wallpaper", color = TextPrimary) },
        text = {
            Column {
                listOf(
                    "Home screen" to WallpaperTarget.HOME,
                    "Lock screen" to WallpaperTarget.LOCK,
                    "Home & lock screen" to WallpaperTarget.BOTH
                ).forEach { (label, target) ->
                    TextButton(onClick = { onPick(target) }, modifier = Modifier.fillMaxWidth()) {
                        Text(label, color = NeonCyan, fontSize = 16.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = TextSecondary) } }
    )
}
