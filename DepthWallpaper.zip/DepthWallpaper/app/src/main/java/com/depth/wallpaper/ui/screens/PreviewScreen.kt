package com.depth.wallpaper.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.BrokenImage
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.PhoneAndroid
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.depth.wallpaper.data.Resolution
import com.depth.wallpaper.data.WallpaperRepository
import com.depth.wallpaper.data.applyWallpaper
import com.depth.wallpaper.data.shareFile
import com.depth.wallpaper.ui.AppViewModel
import com.depth.wallpaper.ui.components.AppImage
import com.depth.wallpaper.ui.components.EmptyState
import com.depth.wallpaper.ui.components.GlassIconButton
import com.depth.wallpaper.ui.components.GlassSurface
import com.depth.wallpaper.ui.components.GradientButton
import com.depth.wallpaper.ui.components.SetWallpaperDialog
import com.depth.wallpaper.ui.theme.Amoled
import com.depth.wallpaper.ui.theme.ElectricBlue
import com.depth.wallpaper.ui.theme.HeartRed
import com.depth.wallpaper.ui.theme.NeonCyan
import com.depth.wallpaper.ui.theme.TextSecondary
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Composable
fun PreviewScreen(vm: AppViewModel, nav: NavHostController, id: String?) {
    val wallpaper = remember(id) { id?.let { WallpaperRepository.byId(it) } }
    if (wallpaper == null) {
        EmptyState(
            icon = Icons.Outlined.BrokenImage,
            title = "Wallpaper not found",
            subtitle = "It may have been removed.",
            actionLabel = "Go back",
            onAction = { nav.popBackStack() }
        )
        return
    }

    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val downloads by vm.downloads.collectAsStateWithLifecycle()
    val quality by vm.quality.collectAsStateWithLifecycle()

    var resIdx by rememberSaveable { mutableIntStateOf(quality.ordinal) }
    val res = Resolution.values()[resIdx]
    var overlay by rememberSaveable { mutableStateOf(false) }
    var showSet by remember { mutableStateOf(false) }

    val key = "${wallpaper.id}__${res.name}"
    val pct = progress[key]
    val isDownloaded = downloads.any { it.file.name == "$key.jpg" }
    val isFav = wallpaper.id in favs

    Box(Modifier.fillMaxSize().background(Amoled)) {
        AppImage(wallpaper.url(Resolution.HD), Modifier.fillMaxSize(), placeholderUrl = wallpaper.thumb())
        if (overlay) HomePreviewOverlay()

        Box(
            Modifier.fillMaxWidth().height(140.dp).align(Alignment.TopCenter)
                .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.6f), Color.Transparent)))
        )
        Box(
            Modifier.fillMaxWidth().height(340.dp).align(Alignment.BottomCenter)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.88f))))
        )

        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(16.dp).align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            GlassIconButton(Icons.AutoMirrored.Outlined.ArrowBack, "Back") { nav.popBackStack() }
            GlassIconButton(
                if (overlay) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
                "Preview on home screen"
            ) { overlay = !overlay }
        }

        Column(
            Modifier.align(Alignment.CenterEnd).padding(end = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            ActionButton(
                if (isFav) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                "Like",
                if (isFav) HeartRed else Color.White
            ) { vm.toggleFavorite(wallpaper.id) }
            ActionButton(Icons.Outlined.Download, "Download") {
                if (pct == null) vm.download(wallpaper, res)
            }
            ActionButton(Icons.Outlined.PhoneAndroid, "Set As") { showSet = true }
            ActionButton(Icons.Outlined.Share, "Share") {
                scope.launch {
                    vm.say("Preparing…")
                    vm.fetch(wallpaper, res)
                        .onSuccess { shareFile(ctx, it) }
                        .onFailure { vm.say("Couldn't prepare the image. Check your connection.") }
                }
            }
        }

        Column(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp)
        ) {
            Text(wallpaper.title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(wallpaper.category, color = TextSecondary, fontSize = 13.sp)
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Resolution.values().forEach { r ->
                    val sel = r == res
                    GlassSurface(
                        Modifier
                            .weight(1f)
                            .height(58.dp)
                            .then(if (sel) Modifier.border(2.dp, ElectricBlue, RoundedCornerShape(16.dp)) else Modifier),
                        RoundedCornerShape(16.dp),
                        glow = if (sel) ElectricBlue.copy(alpha = 0.6f) else null,
                        onClick = { resIdx = r.ordinal }
                    ) {
                        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(r.label, color = if (sel) NeonCyan else Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(r.dims, color = TextSecondary, fontSize = 10.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            val label = when {
                pct != null -> "Downloading ${(pct * 100).toInt()}%"
                isDownloaded -> "Downloaded · Open Downloads"
                else -> "Download Wallpaper"
            }
            GradientButton(
                text = label,
                modifier = Modifier.fillMaxWidth(),
                icon = Icons.Outlined.Download,
                enabled = pct == null,
                progress = pct
            ) {
                if (isDownloaded) nav.navigate("downloads") else vm.download(wallpaper, res)
            }
        }
    }

    if (showSet) {
        SetWallpaperDialog(onDismiss = { showSet = false }) { target ->
            showSet = false
            scope.launch {
                vm.say("Preparing wallpaper…")
                vm.fetch(wallpaper, res)
                    .onSuccess { file ->
                        applyWallpaper(ctx, file, target)
                            .onSuccess { vm.say("Wallpaper set!") }
                            .onFailure { vm.say("Couldn't set wallpaper: ${it.message}") }
                    }
                    .onFailure { vm.say("Download failed. Check your connection and try again.") }
            }
        }
    }
}

@Composable
private fun ActionButton(icon: ImageVector, label: String, tint: Color = Color.White, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        GlassIconButton(icon, label, tint = tint, size = 50.dp, onClick = onClick)
        Spacer(Modifier.height(3.dp))
        Text(label, color = Color.White, fontSize = 11.sp)
    }
}

/** Fake lock/home screen on top of the wallpaper so you can judge how it will look. */
@Composable
private fun HomePreviewOverlay() {
    val now = remember { LocalDateTime.now() }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().padding(top = 80.dp, bottom = 330.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")), color = Color.White.copy(alpha = 0.9f), fontSize = 16.sp)
        Text(now.format(DateTimeFormatter.ofPattern("h:mm")), color = Color.White, fontSize = 88.sp, fontWeight = FontWeight.Light)
        Spacer(Modifier.weight(1f))
        val icons = listOf(
            Icons.Outlined.Call, Icons.Outlined.Email, Icons.Outlined.Public, Icons.Outlined.CameraAlt,
            Icons.Outlined.MusicNote, Icons.Outlined.Settings
        )
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            icons.take(4).forEach { AppIconTile(it) }
        }
    }
}

@Composable
private fun AppIconTile(icon: ImageVector) {
    GlassSurface(Modifier.size(54.dp), RoundedCornerShape(16.dp)) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.align(Alignment.Center).size(26.dp))
    }
}
