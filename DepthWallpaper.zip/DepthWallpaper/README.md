# Depth Wallpaper (Android, Jetpack Compose)

Dark AMOLED + Liquid Glass wallpaper app. Package: `com.depth.wallpaper`.

## Build in the GitHub cloud (no Android Studio needed)
1. Create a new GitHub repository.
2. Upload this whole project to it (keep the hidden `.github/workflows/build.yml` file!).
3. Open the repo -> **Actions** tab -> **Build APK** -> **Run workflow** (it also runs on every push to main).
4. When the run turns green, open it and download the artifact **DepthWallpaper-debug-apk**.
5. Unzip it and install `app-debug.apk` on your phone (allow "install unknown apps").

## What is real
- Home, Explore (search / categories / sort / infinite scroll), Preview, Favorites, Downloads, Create, Profile
- Favourites + quality preference saved with DataStore
- Downloads saved in app storage (offline, no storage permission), progress, dedupe, share, delete
- Set wallpaper: Home / Lock / Both via WallpaperManager
- Create: Blur, Color Filters, 3D (chromatic/anaglyph), Artistic (pixel/posterize/duotone) run on-device
  using the system photo picker

## What is intentionally NOT faked
- AI wallpaper generation -> needs your own backend (card shows setup instructions)
- Depth / Parallax effects -> need a depth model + live wallpaper service (card explains)
- Pro billing -> needs Google Play Billing

## Using your own wallpapers
The demo catalogue uses picsum.photos (no key). Replace `WallpaperRepository.all`
in `data/Models.kt` with data from your own server. Never put secret API keys in the app.

## Links
Fill `AppConfig` in `data/Models.kt` (privacy, terms, feedback email).
